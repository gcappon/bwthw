//This class acts as data repository for the product catalog of the store.
class Catalog{

  //For simplicity, a product is represented as a String. 
  List<String> products = ['Ham', 'Cheese','Wine', 'Pasta'];
  
}//Catalog