package com.example.shopper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
