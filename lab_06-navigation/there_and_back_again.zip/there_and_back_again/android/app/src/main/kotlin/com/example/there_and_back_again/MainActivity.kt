package com.example.there_and_back_again

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
